<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class TamuController extends Controller
{
    public function index(){
        $data = User::all();
        return view('Admin.Tamu.index', compact('data'));
    }

    public function formTambah(){
        return view('Admin.formTambah');
        
    }

    public function simpanData(Request $request){
        $request->validate([
            'nama' => 'required|string|max:255',
            'telepon' => 'required|string|max:255',
            'alamat' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
        ]);
    
        $data = new User;
        $data->nama = $request->nama;
        $data->tlp = $request->telepon;
        $data->alamat = $request->alamat;
        $data->email = $request->email;
        $data->password = Hash::make('rahasia');
    
        $data->save();
    
        return redirect('admin/tamu')->with('status', 'Data Berhasil Disimpan');
    }
    
    public function formEdit($id){
        $data = User::find($id);

        return view('Admin.Tamu.formEdit', compact('data'));
    }

    public function updateTamu(Request $request, $id){
        $request->validate([
            'nama' => 'required|string|max:255',
            'telepon' => 'required|string|max:255',
            'alamat' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users,email,'.$id,
        ]);
    
        $data = User::find($id);
        if ($data) {
            $data->nama = $request->nama;
            $data->tlp = $request->telepon;
            $data->alamat = $request->alamat;
            $data->email = $request->email;
            // Assume password is not updated here
    
            $data->save();
        
            return redirect('admin/tamu')->with('status', 'Data Berhasil Diperbarui');
        } else {
            return redirect('admin/tamu')->with('status', 'Data Tidak Ditemukan');
        }
    }
      
    public function hapusTamu($id){
        $data = User::find($id);
        if ($data) {
            $data->delete();
            return redirect('admin/tamu')->with('status', 'Data Berhasil Dihapus');
        } else {
            return redirect('admin/tamu')->with('status', 'Data Tidak Ditemukan');
        }
    }
}

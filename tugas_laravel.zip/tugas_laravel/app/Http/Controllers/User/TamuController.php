<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\User; // Pastikan namespace model User sesuai dengan struktur direktori
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class TamuController extends Controller
{
    public function simpanTamu(Request $request)
    {
        $nama    = $request->nama;
        $telepon = $request->telepon;
        $email   = $request->email;
        $alamat  = $request->alamat;

        // Simpan data ke dalam tabel User
        $user = new User();
        $user->nama = $nama; // Pastikan nama properti sesuai dengan kolom yang ada di tabel
        $user->tlp = $telepon; // Sesuaikan dengan nama kolom yang benar
        $user->email = $email; // Pastikan nama properti sesuai dengan kolom yang ada di tabel
        $user->alamat = $alamat; // Sesuaikan dengan nama kolom yang benar
        $user->password = Hash::make('rahasia'); // Contoh menggunakan Hash untuk enkripsi password
        $user->save();

        // Redirect dengan pesan sukses
        return redirect('/')->with('status', 'Data Berhasil Disimpan');
    }
}

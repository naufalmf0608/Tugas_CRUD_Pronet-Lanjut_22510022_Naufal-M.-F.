@extends('app')
@section('content')
<div class="card">
  @if (session('status'))
      <div class="alert alert-success">
       {{ session('status') }}
      </div>
  @endif
    <div class="card-header">
      <h4> Data Buku Tamu </h4><br>
      <a href="{{url('admin/form-tambah')}}" class="btn btn-success">Tambah +</a>
    </div>
    <div class="card-body">
        <table class="table" id="myTable">
            <thead class="thead-dark">
              <tr>
                <th scope="col">No</th>
                <th scope="col">Nama</th>
                <th scope="col">Telepon</th>
                <th scope="col">Alamat</th>
                <th scope="col">Email</th>
                <th scope="col">Aksi</th>
              </tr>
            </thead>
            <tbody>
                @foreach($data as $key => $item)
                <tr>
                  <td>{{ $item->id }}</td>
                  <td>{{ $item->nama }}</td>
                  <td>{{ $item->tlp }}</td>
                  <td>{{ $item->alamat }}</td>
                  <td>{{ $item->email }}</td>
                  <td>
                      <a href="{{ url('admin/form-edit', $item->id) }}" class="btn btn-warning">Edit</a>
                      <form action="{{ url('admin/tamu', $item->id) }}" method="POST" style="display:inline;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</button>
                    </form>
                  </td>
              </tr>
              @endforeach
          </tbody>
      </table>
  </div>
</div>
@endsection

@section('script')
<script>
  let table = new DataTable('#myTable');
</script>
@endsection
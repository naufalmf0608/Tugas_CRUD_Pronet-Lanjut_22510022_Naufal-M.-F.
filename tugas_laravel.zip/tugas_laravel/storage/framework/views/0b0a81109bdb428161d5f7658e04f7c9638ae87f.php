
<?php $__env->startSection('content'); ?>
<div class="card">
  <?php if(session('status')): ?>
      <div class="alert alert-success">
       <?php echo e(session('status')); ?>

      </div>
  <?php endif; ?>
    <div class="card-header">
      <h4> Data Buku Tamu </h4><br>
      <a href="<?php echo e(url('admin/form-tambah')); ?>" class="btn btn-success">Tambah +</a>
    </div>
    <div class="card-body">
        <table class="table" id="myTable">
            <thead class="thead-dark">
              <tr>
                <th scope="col">No</th>
                <th scope="col">Nama</th>
                <th scope="col">Telepon</th>
                <th scope="col">Alamat</th>
                <th scope="col">Email</th>
                <th scope="col">Aksi</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($item->id); ?></td>
                  <td><?php echo e($item->nama); ?></td>
                  <td><?php echo e($item->tlp); ?></td>
                  <td><?php echo e($item->alamat); ?></td>
                  <td><?php echo e($item->email); ?></td>
                  <td>
                      <a href="<?php echo e(url('admin/form-edit', $item->id)); ?>" class="btn btn-warning">Edit</a>
                      <form action="<?php echo e(url('admin/tamu', $item->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</button>
                    </form>
                  </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
  let table = new DataTable('#myTable');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tes_laravel\tugas_laravel\resources\views/Admin/Tamu/index.blade.php ENDPATH**/ ?>
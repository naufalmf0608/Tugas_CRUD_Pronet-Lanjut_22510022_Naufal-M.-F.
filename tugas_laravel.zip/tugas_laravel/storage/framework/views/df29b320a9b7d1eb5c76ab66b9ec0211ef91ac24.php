<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('admin.tamu.index')); ?>">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Aplikasi Bukutamu</div>
    </a>

    <hr class="sidebar-divider">

    <div class="sidebar-heading">
        Interface
    </div>

    <li class="nav-item <?php echo e(Request::is('admin/tamu') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('admin.tamu.index')); ?>">
            <i class="fas fa-fw fa-users"></i>
            <span>Data Bukutamu</span></a>
    </li>

</ul><?php /**PATH C:\xampp\htdocs\tes_laravel\tugas_laravel\resources\views/Layouts/sidebar.blade.php ENDPATH**/ ?>
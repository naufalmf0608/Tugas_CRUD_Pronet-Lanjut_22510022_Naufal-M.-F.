
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-center">
<div class="card" style="width: 40%">
    <div class="card-header">
      Form Edit Buku Tamu
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('admin.tamu.update', $data->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
            <div class="form-group">
                <label for="nama">Nama</label>
                <input type="text" name="nama" class="form-control" value="<?php echo e($data->nama); ?>">
            </div>
            <div class="form-group">
                <label for="telepon">Telepon</label>
                <input type="text" name="telepon" class="form-control" value="<?php echo e($data->tlp); ?>">
            </div>
            <div class="form-group">
                <label for="alamat">Alamat</label>
                <input type="text" name="alamat" class="form-control" value="<?php echo e($data->alamat); ?>">
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" name="email" class="form-control" value="<?php echo e($data->email); ?>">
            </div>
            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        </form>
        
        </div>      
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tes_laravel\tugas_laravel\resources\views/Admin/Tamu/formEdit.blade.php ENDPATH**/ ?>
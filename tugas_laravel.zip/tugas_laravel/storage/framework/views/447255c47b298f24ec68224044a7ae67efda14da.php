<footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Naufal M. F.</span>
                    </div>
                </div>
            </footer><?php /**PATH C:\xampp\htdocs\tes_laravel\tugas_laravel\resources\views/Layouts/footer.blade.php ENDPATH**/ ?>
<!-- Bootstrap core JavaScript-->
<script src="<?php echo e(asset('/backend/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('/backend/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<!-- Core plugin JavaScript-->
<script src="<?php echo e(asset('/backend/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

<!-- Custom scripts for all pages-->
<script src="<?php echo e(asset('/backend/js/sb-admin-2.min.js')); ?>"></script>

<!-- Page level plugins -->
<script src="<?php echo e(asset('/backend/js/dataTable.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<?php /**PATH C:\xampp\htdocs\tes_laravel\tugas_laravel\resources\views/Layouts/js.blade.php ENDPATH**/ ?>